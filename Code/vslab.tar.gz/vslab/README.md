To build and run from command line:

```
mkdir build
cd build
cmake ..
make
./vslab <args>
```

Note: you need to build CAF first (in parent directory)
